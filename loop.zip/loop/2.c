#include<stdio.h>
 main(){
    int i=10;
    printf("Desending order are given below \n");
    while(i >= 1){
        
        printf("%d\n",i);
        i--;
    }
 }