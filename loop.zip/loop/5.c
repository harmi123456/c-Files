#include<stdio.h>
 main(){
    int x,y;

    printf("Enter any year :");
    scanf("%d",&x);
    printf("Enter any year :");
    scanf("%d",&y);

    while(x<=y){
        if(x%4 == 0){
            printf("%d\n",x);

        } x++;
    }
 }