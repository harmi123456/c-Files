#include<stdio.h>
 main(){
    int i=1;
    printf("Acending order are given below");
    while(i <= 10){
        printf("%d\n",i);
        i++;
    }
 }