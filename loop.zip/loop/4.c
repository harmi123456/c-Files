#include<stdio.h>
 main(){
    int odd=0,odd_1;

    printf("Enter any number : ");
    scanf("%d",&odd_1);

    while(odd_1 >= odd){
        if(odd_1 %2!=0){
            printf(" %d \n",odd_1);
        }
        odd_1--;
    }
 }