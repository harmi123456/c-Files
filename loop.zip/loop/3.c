#include<stdio.h>
 main(){
    int finite =1 ,a;

    printf("Enter any number : ");
    scanf("%d",&a);

    while(finite <= a){
        printf("%d \n",finite);
        finite++;
    }
 }