#include<stdio.h>
 main(){

    int distance=50;
    int time=10;
    int a=distance/time;

    printf("value of distance = %d\n",distance);
    printf("value of time = %d\n",time);
    printf("the velocity of time is : %d",a);
    
 }