#include<stdio.h>
 main(){
     printf("1.sum of two values\n");
     int a=5;
     int b=3;
     int c=a+b;
     printf("value of a : %d\n",a);
     printf("value of b : %d\n",b);
     printf("sum of two values : %d",c);
}
 