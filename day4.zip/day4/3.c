#include<stdio.h>
 main(){
     printf("1.sum of two values\n");
     int a=10;
     int b=20;
     int c=30;
     int d=a+c%b;
     printf("value of a : %d\n",a);
     printf("value of b : %d\n",b);
     printf("value of c : %d\n",c);

     printf("average of three values : %d",d);
}