#include<stdio.h>
 main(){
    int a;
    printf("Enter value of a:");
    scanf("%d",&a);
    int b=a*9;
    printf("answer is : %d",b);
 }