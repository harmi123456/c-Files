#include<stdio.h>
 main(){
     printf("1.multiplication of two values\n");
     int a=4;
     int b=6;
     int c=a*b;
     printf("value of a : %d\n",a);
     printf("value of b : %d\n",b);
     printf("sum of two values : %d",c);
}