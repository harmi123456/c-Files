#include<stdio.h>
 main(){
    int a,b,c,d;
    a=5;
    b=3;
    c=7;
    d=2;
    int e=(a+b)*(c-d);

    printf("The final ans is : %d",e);
 }