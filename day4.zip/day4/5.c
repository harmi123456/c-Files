#include<stdio.h>
 main(){
     int p,r,n;
     p=1000;
     r=5;
     n=2;
     int a=p*r*n/100;

     printf("value of p= %d\n",p);
     printf("value of r= %d\n",r);
     printf("value of n= %d\n",n);
     printf("simple interest is : %d\n",a);
 }
 