#include <stdio.h>
int main(){
    int a=2;
    int b=a*a*a;

    printf("value of a : %d\n",a);
    printf("the final ans is : %d",b);
}