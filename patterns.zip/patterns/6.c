#include<stdio.h>
 main(){
     int row,column;
    
    
    for(row=1; row<=5; row++){
        for(column=row; column<=5; column++){
            printf("%d",column%2);
        } printf("\n");
    } 
 }