#include<stdio.h>
 main(){
     int a=1;
    do{
        printf("%d\n",a);
        a++;
    } 
    while(a<=10);
 }