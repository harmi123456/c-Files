#include <stdio.h>
int main(){
    int a,b;
    printf("Enter value of");
    scanf("Enter the value of a= %d",&a);

    b=2*a*3.14;

    printf("Enter the value of",&b);
}