#include<stdio.h>
 main(){
    printf("start the program\n\n");
    printf("1. area of rectangle\n");
    int w=5;
    int l=8;
    int c=l*w;
    printf("value of w %d \n", w);
    printf("value of l %d\n", l);
    printf("Area of rectangle %d\n\n\n", c);

    printf("2. area of squre\n");
    int a,b;
    a=3;
    b=a*a;
    printf("area of squre %d\n\n\n", b);

    printf("3. sum of two values\n");
    int d=5;
    int e=4;
    int f=d+e;
    printf("value of d %d\n", d);
    printf("value of e %d\n", e);
    printf("sum of two values %d\n\n\n", f);

    printf("4. division of two values\n");
    int g=50;
    int h=10;
    int i=g/h;
    printf("value of g %d\n", g);
    printf("value of h %d\n", h);
    printf("division of two values %d\n\n\n", i);

    printf("5. sum of three numbers\n");
    int j=20;
    int k=19;
    int m=j+k;
    printf("value of j %d\n", j);
    printf("value of k %d\n", k);
    printf("sum of three numbers %d\n\n\n", m);

    printf("6. multiplication of two values\n");
    int x=5;
    int y=7;
    int z=x*y;
    printf("value of x %d\n", x);
    printf("value of y %d\n", y);
    printf("multiplication of two values %d\n\n\n", z);

    printf("7. perimeter of renctangle\n");
    int wi=20;
    int le=50;
    int pe=2*(wi+le);
    printf("width: %d\n", wi);
    printf("length: %d\n", le);
    printf(" perimeter of ranctangle %d\n\n\n", pe);


    printf("8. perimeter of squre\n");
    int s=30;
    int t=s*4;
    printf(" value of s %d\n", s);
    printf(" perimeter of squre %d\n\n\n",t);


    printf(" work has been comleted\n\n");
 }