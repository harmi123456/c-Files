#include<stdio.h>
 main(){
   printf("Start the program\n\n\n");
   printf("My name is harmi pagada\n");
   printf("i'm 17 years old\n");
   printf("now i'm studying full stack development at red & white multimedia education\n\n\n");


   printf("--------\n");
   printf("| \t |\n");
   printf("R \t |\n");
   printf("N \t |\n");
   printf("W \t |\n");
   printf("| \t |\n");
   printf("--------\n\n\n");


   printf(" * \n ** \n *** \n ** \n * \n\n\n");


    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("*\t    * *\t\t   *\n");
    printf("*       *     *          *\n");
    printf("*     *         *      *\n");
    printf("*   *             *  *\n");

    printf("* *\n");
    printf("*\n");

   printf("today's work has been complete");




 }